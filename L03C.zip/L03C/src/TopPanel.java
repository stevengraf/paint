
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class TopPanel extends JPanel{
    
    ColorButton blue, green, red, cyan, black, white;
    OptionButton increase, decrease, circle, squares;
    
    
    TopPanel(){
        super();
        this.setBackground(Color.gray);
        GridLayout lay1 = new GridLayout(2, 2, 5, 5);
        setLayout(lay1);
        
        blue = new ColorButton("Blue", Color.blue);
        green = new ColorButton("Green", Color.green);
        red = new ColorButton("Red", Color.red);
        cyan = new ColorButton("Cyan", Color.cyan);
        black = new ColorButton("Black", Color.black);
        white = new ColorButton("Eraser", Color.white);

        
        
        increase = new OptionButton("+");
        decrease = new OptionButton("-");
        circle = new OptionButton("Circles");
        squares = new OptionButton("Squares");

        add(squares);
        add(increase);
        add(blue);
        add(green);
        add(red);
        add(circle);
        add(decrease);
        add(cyan);
        add(black);
        add(white);
    }
}
