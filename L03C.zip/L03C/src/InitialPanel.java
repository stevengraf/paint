
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class InitialPanel extends JPanel {
    private TopPanel top;
    private DrawingPanel draw;
    private StatusPanel status;
    
    public InitialPanel()
    {
        super();
        setBackground(Color.gray);
        setLayout(new BorderLayout());
        
        
        top = new TopPanel();
        add(top,BorderLayout.NORTH);
        draw = new DrawingPanel(top);
        add(draw,BorderLayout.CENTER);
        status = new StatusPanel(top, draw);
        add(status,BorderLayout.SOUTH);
    }
    
    
}
