import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class InitialFrame extends JFrame{
    
    InitialPanel initialPanel;
    
    InitialFrame(String strTitle){
        super(strTitle);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        initialPanel = new InitialPanel();
        add(initialPanel);
        
        this.setSize(1000, 800);
        setVisible(true);
    }
    
}
