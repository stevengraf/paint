
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class DrawingPanel extends JPanel implements MouseMotionListener, ActionListener{
    
    JButton x, y;
    Graphics g;
    TopPanel top;
    Color currentColor;
    ArrayList<Rectangle> rectangles = new ArrayList();
    ArrayList<Color> rectColors = new ArrayList();
    
    ArrayList<Oval> ovals = new ArrayList();
    ArrayList<Color> ovalColors = new ArrayList();
    
    int size;
    int option;
    
    DrawingPanel(TopPanel top){
        super();
        setBackground(Color.white);
        addMouseMotionListener(this);
        this.top = top;
        
        top.blue.addActionListener(this);
        top.green.addActionListener(this);
        top.red.addActionListener(this);
        top.cyan.addActionListener(this);
        top.black.addActionListener(this);
        top.white.addActionListener(this);
        
        top.increase.addActionListener(this);
        top.decrease.addActionListener(this);
        top.squares.addActionListener(this);
        top.circle.addActionListener(this);
        
        size = 5;
        option = 0;
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        Point pt = me.getPoint();
        g = getGraphics();
        
        if (option == 0){
            g.setColor(currentColor);
            g.fillRect(pt.x, pt.y, size, size);
            Rectangle r = new Rectangle(pt.x, pt.y, size, size);
            rectangles.add(r);
            rectColors.add(currentColor);
        }
        
        if (option == 1){
            g.setColor(currentColor);
            g.fillOval(pt.x, pt.y, size, size);
            Oval o = new Oval(pt.x, pt.y, size, size);
            ovals.add(o);
            ovalColors.add(currentColor);
        }
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        for(int x = 0; x < rectangles.size(); x++){
            g.setColor(rectColors.get(x));
            g.fillRect(rectangles.get(x).x, rectangles.get(x).y, rectangles.get(x).width, rectangles.get(x).height);
        }
        
        for(int y = 0; y < ovals.size(); y++){
            g.setColor(ovalColors.get(y));
            g.fillOval(ovals.get(y).x, ovals.get(y).y, ovals.get(y).width, ovals.get(y).width);
        }
    }

    @Override
    public void mouseMoved(MouseEvent me) {
        
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Object obj = event.getSource();
        if(obj == top.blue){
            currentColor = top.blue.getColor();
        }
        if(obj == top.green){
            currentColor = top.green.getColor();
        }
        if(obj == top.red){
            currentColor = top.red.getColor();
        }
        if(obj == top.cyan){
            currentColor = top.cyan.getColor();
        }
        if(obj == top.black){
            currentColor = top.black.getColor();
        }
        if(obj == top.white){
            currentColor = top.white.getColor();
        }
        
        if(obj == top.increase){
            size++;
        }
        if(obj == top.decrease){
            size--;
        }
        if(obj == top.squares){
            option = 0;
        }
        if(obj == top.circle){
            option = 1;
        }
    }
    
    
}
