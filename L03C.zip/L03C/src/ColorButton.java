
import java.awt.Color;
import javax.swing.JButton;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class ColorButton extends JButton{
    Color newColor;
    String colorText;
    
    ColorButton(String colorText, Color color){
        super(colorText);
        newColor = color;
        this.colorText = colorText;
        setBackground(newColor);
    }
    
    public Color getColor(){
        return newColor;
    }
    
    public String getColorText(){
        return colorText;
    }
}
