
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sog5204
 */
public class StatusPanel extends JPanel implements ActionListener, MouseMotionListener{
    TopPanel top;
    DrawingPanel draw;
    JLabel L1;
    JLabel L2;
    
    StatusPanel(TopPanel top, DrawingPanel draw){
        super();
        GridLayout lay1 = new GridLayout(1, 2, 5, 5);
        setLayout(lay1);
        this.top = top;
        L1 = new JLabel("Current Color: Black");
        L2 = new JLabel();
        add(L2);
        add(L1);
        draw.addMouseMotionListener(this);
        top.blue.addActionListener(this);
        top.green.addActionListener(this);
        top.red.addActionListener(this);
        top.cyan.addActionListener(this);
        top.black.addActionListener(this);
        top.white.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Object obj = event.getSource();
        if(obj == top.blue){
            L1.setText("Current Color: " + top.blue.getColorText());
        }
        if(obj == top.green){
            L1.setText("Current Color: " + top.green.getColorText());
        }
        if(obj == top.red){
            L1.setText("Current Color: " + top.red.getColorText());
        }
        if(obj == top.cyan){
            L1.setText("Current Color: " + top.cyan.getColorText());
        }
        if(obj == top.black){
            L1.setText("Current Color: " + top.black.getColorText());
        }
        if(obj == top.white){
            L1.setText("Current Color: " + top.white.getColorText());
        }
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        Point pt = me.getPoint();
        L2.setText("(" + Integer.toString(pt.x)+ "," + Integer.toString(pt.y)+")");
    }

    @Override
    public void mouseMoved(MouseEvent me) {
        Point pt = me.getPoint();
        L2.setText("(" + Integer.toString(pt.x)+ "," + Integer.toString(pt.y)+")");
    }
    
    
    
    
}
